/*
 * @File:   tempSensor.h
 * @Author: Kye Ridley-Smith
 * @Date    Created on 26 October 2014
 * @brief   This file declares and defines the variables needed for any
 *          functions associated with the temperature sensor.
 */

/// Ensure the tempsensor.h file is named correctly
#ifndef TEMPSENSOR_H
#define	TEMPSENSOR_H

/// Define TRUE and FALSE for easy use throughout
#define TRUE    1
#define FALSE   0

/// Function declarations of all functions associated with the temp sensor
void tempSensor(void);
void calibrateTempSensor(void);
void clearCalibationOffset(void);
void tempSensorInitialisation(void);

/// Set the 2 states to be checked when the function is called.
/// numbered sequentially 0 and 1
enum AD_STATES {
    ADCSETUP,
    CALCULATE_TEMPERATURE,
};

/// Define variables called by any temp sensor module externally so other
/// functions may make use of them and be able to see their values.
extern int temperatureReading;
extern int temperaturemV;           
extern int temperatureDegC;         
extern int temperatureOffset;
extern int tempSensorDelay;         
extern int calibrationTemperature;  

#endif  /* TEMPSENSOR_H */





/*
 * @File:   tempSensor.c
 * @Author: Kye Ridley-Smith
 * @Date    Created on 26 October 2014
 * @brief   This file holds the routines for all functions associated with the
 *          temperature sensor
 */


#include "masterHeader.h"

/// Define set values for certain names that can be easily changed
#define SUPPLY_VOLTAGE      500             ///< Vary this to match exact mV
#define AD_READING          ADRES           ///< Location of ADC values
#define ADCON0_AD_SETTING   0b01001001      ///< Fosc/8, A/D enable, RA1
#define ADCON1_AD_SETTING   0b10001110      ///< Right justify, 1 analog channel
#define TEMPERATURE_PIN     PORTAbits.RA1   ///< Use RA1 for our TempSensor ADC
#define TEMPERATURE_DDR     TRISAbits.RA1   ///< DDR = Data Direction Register

/// Define initial variable values
int temperatureReading = 0;         ///< Initialise the ADC value to 0
int temperaturemV = 0;              ///< Initialise temperature voltage to 0
int temperatureDegC = 25;           ///< Set initial temp to 25 DegC (standard)
int temperatureOffset = 0;          ///< set the temperature offset to 0
int tempSensorDelay = 1000;         ///< Set temp to only update every 1 second
int calibrationTemperature = 0;     ///< User input calibration temp set to 0

/// TimeTag for the next time the function tempSensor() is to be called. 
/// We set it to 3 minutes to allow for the temperature sensor to stabilise
timeTag tempSensorTimer = {0,3,0,0};

/// Create a struct for the flags required for temperature conversion
typedef struct tempFlagsType{
	unsigned char tempState: 1;     ///< Current state of the temp Sensor
        unsigned char tempConverting: 1;///< Signals when the ADC is busy
}tempFlagsType;

/** Initially set the flags of tempFlags such that: 
*   tempState = ADCSETUP so the function sets up the ADC when first called
*   tempConverting = 0 which signals that the system is not converting to start
*/
tempFlagsType tempFlags={ADCSETUP,0};

/** @brief This function will be called regularly in the main, each time the
 *  program runs through fully. The function then does 3 checks and performs
 *  various functions accordingly.
 *  1. If the function is not due (i.e. its timer tag has not been reached by
 *     system timer) OR the IR sensor is busy (signalled by IRFlags.idle), the
 *     function shall exit and return and the program counter will return to its
 *     previous location in program memory.
 *  2. If the function is due, the IR sensor isn't busy and the tempState flag
 *     is set to ADCSETUP, the program shall proceed to initialise the ADC
 *     module so it can read the temperature sensor value. It will then reset
 *     the timerTag so the function is called again in 1 second and also set the
 *     tempState flag to CALCULATE_TEMPERATURE so the function will go into
 *     the calculate temperature sub routine at next call.
 *  3. If the function is due, the IR sensor isn't busy and the tempState flag
 *     is set to CALCULATE_TEMPERATURE, the program shall check if the
 *     conversion is complete. If it is, the program shall proceed to read the
 *     ADC value and convert it to a useable temperature in Degrees Celsius. The
 *     tempState flag is set to ADCSETUP so the setup routine is entered again
 *     at next function call and the timerTag is reset so the function is called
 *     again in 1 second. If the conversion complete flag is not set, the
 *     function will set the timerTag to call the function again in 1 second.
 *
 *  @param void
 *  @return void
 */
void tempSensor(void){
/// If an event is not due OR the IR sensor is busy, return from the function
    if(!eventDue(&tempSensorTimer)||(IRFlags.idle == 0)){
        return;
    }

/// If the temperature function flag is set to ADCSETUP, enter the setup routine
    else if(tempFlags.tempState == ADCSETUP){
            ADCON0 = ADCON0_AD_SETTING;         ///< Set ADCON0 to defined value
            ADCON1 = ADCON1_AD_SETTING;         ///< Set ADCON0 to defined value
            /// Set state to go to calculate temp next time the fn. is called
            tempFlags.tempState = CALCULATE_TEMPERATURE;
            ADCON0bits.GO = 1;                  ///< Start ADC
            /// Set flag to indicate that the ADC is busy with the tempSensor
            /// so that the IR sensor does not attempt to use the ADC
            tempFlags.tempConverting = 1;
            /// Set the next time for the temperature function to be called
            setTimeTag(tempSensorDelay, &tempSensorTimer);
            return;                             ///< Return from the function
    }

/// If the temperature function flag, tempState,is set to CALCULATE_TEMPERATURE,
/// enter the calculate temperature routine and read and convert the ADC value
    else if(tempFlags.tempState == CALCULATE_TEMPERATURE){              
        /// If the conversion flag is set, there is data to be harvested
        if (PIR1bits.ADIF){
            /// Store the ADC value into ADRES (Defined as AD_READING)
            temperatureReading = AD_READING;
            /// Convert the temperature reading into a voltage in mV
            /// Make the value an int so it works well with the intToDisplay fn.
            temperaturemV = (int)(SUPPLY_VOLTAGE*temperatureReading);   
            /// Convert the voltage into DegC by dividing by 1024 (resolution)
            temperatureDegC = temperaturemV >> 10;
            /// Add on the user calibrated offset (initially 0)
            temperatureDegC = temperatureDegC + temperatureOffset;
            /// Clear the ADC busy flag so the ADC can be used again
            PIR1bits.ADIF = 0;
            /// Set the next time for the temperature function to be called
            setTimeTag(tempSensorDelay, &tempSensorTimer);
            /// Set the state to ADCSETUP so the next time the function is 
            /// called it will enter the ADCSETUP routine
            tempFlags.tempState = ADCSETUP;
            /// Set the tempConverting flag to 0 so that when the IR sensor
            /// checks, it sees that the temp sensor is not using the ADC
            tempFlags.tempConverting = 0;
        }
        /// If the conversion complete flag (ADIF) is not set, do nothing
        /// and set the timer tag so the function is called again in 1 second
        else{
            setTimeTag(tempSensorDelay, &tempSensorTimer);
        }
    }
}

/** @brief This function will be called in the main at program start to set the
 *  pin to be used for the temperature sensor (#defined previously) to input
 *  and also clear it so that it has no previously stored value on it.
 * 
 *  @param void
 *  @return void
 */
void tempSensorInitialisation(void){
    TEMPERATURE_PIN = 0x00; ///< Clear the temperature pin (previously defined)
    TEMPERATURE_DDR = INPUT;///< Set the temp pin (previously defined) to input
}

/** @brief This function will be called in the main when the user chooses to
 *  calibrate the temperature sensor in factory mode. The function simply reads
 *  a calibrationTemperature value input by the user, compares it with its own
 *  temperature reading and defines an offset to account for this discrepancy
 *  which is added on to the system temperature each time the temperature
 *  calculations are done.
 *
 * @param void
 * @return void
 */
void calibrateTempSensor(void){
    temperatureOffset = calibrationTemperature - temperatureDegC;
}

///< function which allows for the temperature offset to be easily cleared
/** @brief This function will be called by the main when the user chooses to
 *  clear the calibration offset which they may have input earlier. It simply
 *  resets the value of the temperature offset to 0 so that the temperature
 *  reading is not adjusted during calculations. This function was not actually
 *  called in the main at any time as this feature was not implemented.
 *
 * @param void
 * @return void
 */
void clearCalibrationOffset(void){
    temperatureOffset = 0;
}


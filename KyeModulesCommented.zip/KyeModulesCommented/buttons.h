/*
 * @File:   buttons.h
 * @Author: Kye Ridley-Smith
 * @Date    Created on 26 October 2014
 * @brief   This file declares and defines the button flags as well as any
 *          variables and functions associated with the button handling.
 */

/// Ensure the buttons.h file is named correctly
#ifndef BUTTONS_H
#define	BUTTONS_H

/// Create a struct for the flags required for button handling. The struct
/// contains any flags that may be set when a button is pressed or when the
/// button interrupt service routine runs
typedef struct {
    ///Execution flags
    unsigned int buttonPressed : 1; ///< A button has been pressed
    unsigned int acceptingInput : 1;///< The keypad is active and ready for use
    unsigned int numericalInput : 1;///< The progam is expecting numerical input
                                    ///< (Up and Down disabled)
    /// Specific Button Flags
    unsigned int upPressed : 1;     ///< The up button has been pressed
    unsigned int downPressed : 1;   ///< The down button has been pressed
    unsigned int goPressed : 1;     ///< The go button has been pressed
    unsigned int backPressed : 1;   ///< The back button has been pressed
    unsigned int bufferFull : 1;    ///< The button buffer is full.
                                    ///< Too many keys have been pressed
} ButtonFlags;

/// Define variables/flags used by and buttons module externally so other
/// functions may make use of them and be able to see their values.
extern ButtonFlags buttonFlags;
extern unsigned char buttonPressValue;

/// Define the buttonsSetup funcion externally to be used elsewhere in program
extern void buttonsSetup(void);

#endif	/* BUTTONS_H */


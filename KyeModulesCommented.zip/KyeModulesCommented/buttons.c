/*
 * @File:   buttons.c
 * @Author: Kye Ridley-Smith
 * @Date    Created on 26 October 2014
 * @brief   This file holds the function to setup the button interrupt on PORT B
 *          as well as initialises all buttonFlags (define in buttons.h)
 */

#include "masterHeader.h"

/// Initialise all buttonFlags to 0 so that they are not set at program start
ButtonFlags buttonFlags = {0, 0, 0, 0, 0, 0, 0, 0};

/** Initialise the buttonpressValue to 0 at program start. This is updated 
 *  each time a button is pressed and an interrupt is fired to the number
 *  corresponding to the button pressed.
 */
unsigned char buttonPressValue = 0;

/** @brief This function will be called at program start to initialise the
 *  button interrupt, INT1 on PIN RB1, to fire on a rising edge signal. This
 *  setup routine initialises all interrupts as well as the specific INT1
 *  interrupt needed for the button itnerrupt.
 *
 *  @param void
 *  @return void
 */
void buttonsSetup(void)
{
    /// Set TRISB (the Data Direction Register for PORTB to the given binary
    /// value as well as ensuring any previously defined bits are maintained
    TRISB = 0b00111111 | TRISB;

    /// Interrupt initialisation for all interrupts as well as the specific
    /// INT1 interrupt to be used for the buttons interrupt on pin RB1
    RCONbits.IPEN = HIGH;       ///< Enable priority interrupts
    INTCONbits.GIEH = HIGH;     ///< Enable all high priority interrupts
    INTCONbits.GIEL = HIGH;     ///< Enable all low prioirty interrupts
    INTCON2bits.INTEDG1 = HIGH; ///< Set INT1 to fire on a rising edge only
    INTCONbits.RBIE = LOW;      ///< Ensure the PORTB interrupt on change is OFF
    INTCON3bits.INT1IP = LOW;   ///< Set the INT1 priority to low
    INTCON3bits.INT1IE = HIGH;  ///< Enable the INT1 interrupt to fire
    INTCON3bits.INT1IF = LOW;   ///< Clear the INT1 interrupt fired flag
    
}



